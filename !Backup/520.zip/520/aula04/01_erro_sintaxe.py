#!/usr/bin/python3

nome = input('Digite seu nome: ')
#  print(nome)
# print(name)
print(nome)

ling = input('Digite a melhor linguagem de programação? ')

# if ling.lower().strip() == 'python'
if ling.lower().strip() == 'python':
	print('Você acertou!')
else:
	print('Você errou!')
