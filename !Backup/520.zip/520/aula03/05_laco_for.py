#!/usr/bin/python3

letras = ['a', 'b', 'c', 'd']

for letra in letras:
	print(letra)

print('-------------------')

string = 'Curso de python fundamentals'

for letra in string:
	print(letra)