#!/usr/bin/python3

aux = True
x = 1
while aux:
	print('Executando {}'.format(x))
	if x == 15:
		aux = False
	x += 1

print('Fim do bloco while')