#!/usr/bin/python3

x = 1
while x <= 10:
	print('Número: {}'.format(x))
	x += 1

print('Fim do bloco while')