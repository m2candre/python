#!/usr/bin/python3

print('hello world')


#Variáveis

mensagem = 'hello world'
print(mensagem)