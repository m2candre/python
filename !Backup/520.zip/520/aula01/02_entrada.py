#!/usr/bin/python3

# nome = input('Digite seu nome: ')

# if (nome == "Ivan"):
# 	print('Bem vindo {}'.format(nome))
# else:
# 	print('Nome errado!')


#Função print parâmetros sep e end
#sep = separador dos itens
#end = caractere de fim de linha
# print("Hello", 100, 10.5, sep=':', end='\n\n')

nome = input('Digite seu nome: ')

print('Seja bem vindo', nome)
